"""Restricted Incus host agent. Runs on the host as root; keep its port firewall-restricted."""
import hashlib, hmac, os, re, subprocess, time
from fastapi import FastAPI, Header, HTTPException
from pydantic import BaseModel, Field

SECRET=os.environ.get("AGENT_SHARED_SECRET", "")
if len(SECRET) < 32:
    raise RuntimeError("AGENT_SHARED_SECRET must be at least 32 characters")
app=FastAPI(title="SAM Incus Provisioning Agent", docs_url=None, redoc_url=None)
NAME_RE=re.compile(r"^sam-[0-9]{5,15}-[a-z0-9]{4,8}$")
IMAGE_RE=re.compile(r"^images:(debian/(12|13)|ubuntu/(22.04|24.04)|alpine/3.19)$")

def run(args, timeout=120):
    p=subprocess.run(["incus", *args], text=True, capture_output=True, timeout=timeout)
    if p.returncode: raise HTTPException(502, f"Incus operation failed: {p.stderr[-700:]}")
    return p.stdout.strip()

def auth(x_agent_time: str|None, x_agent_signature: str|None, body: bytes):
    if not x_agent_time or not x_agent_signature:
        raise HTTPException(401,"Missing agent authentication")
    try: stamp=int(x_agent_time)
    except ValueError: raise HTTPException(401,"Invalid timestamp")
    if abs(int(time.time())-stamp)>60: raise HTTPException(401,"Expired request")
    expected=hmac.new(SECRET.encode(), x_agent_time.encode()+b"."+body, hashlib.sha256).hexdigest()
    if not hmac.compare_digest(expected,x_agent_signature): raise HTTPException(401,"Invalid signature")

class Create(BaseModel):
    name: str
    image: str
    ram_gb: int = Field(ge=1, le=48)
    vcores: int = Field(ge=1, le=8)
    disk_gb: int = Field(ge=5, le=500)

class Action(BaseModel):
    name: str
    action: str

class Delete(BaseModel): name: str

@app.get("/health")
def health():
    return {"ok":True,"incus":run(["version"],10)}

@app.post("/v1/create")
async def create(payload: Create, x_agent_time: str|None=Header(None), x_agent_signature: str|None=Header(None)):
    # Request signature verification is performed in middleware.
    if not NAME_RE.fullmatch(payload.name) or not IMAGE_RE.fullmatch(payload.image): raise HTTPException(400,"Invalid instance name or image")
    # Explicit quotas; default profile supplies the NAT bridge NIC.
    run(["launch",payload.image,payload.name,"--config",f"limits.cpu={payload.vcores}","--config",f"limits.memory={payload.ram_gb}GiB","--device",f"root,size={payload.disk_gb}GiB"],240)
    return {"ok":True,"name":payload.name,"state":"RUNNING"}

@app.post("/v1/action")
async def action(payload: Action):
    if not NAME_RE.fullmatch(payload.name): raise HTTPException(400,"Invalid instance name")
    commands={"start":["start"],"stop":["stop"],"restart":["restart"],"state":["info","--format","json"]}
    if payload.action not in commands: raise HTTPException(400,"Unsupported action")
    out=run([*commands[payload.action],payload.name] if payload.action!="state" else ["info",payload.name,"--format","json"],60)
    return {"ok":True,"result":out[-3000:]}

@app.post("/v1/delete")
async def delete(payload: Delete):
    if not NAME_RE.fullmatch(payload.name): raise HTTPException(400,"Invalid instance name")
    run(["delete",payload.name,"--force"],120)
    return {"ok":True}

@app.get("/v1/list")
def list_instances():
    return {"instances":run(["list","--format","json"],30)}

# HMAC middleware authenticates all /v1 requests against the exact raw body.
from starlette.middleware.base import BaseHTTPMiddleware
from starlette.requests import Request
from starlette.responses import Response
class HMACMiddleware(BaseHTTPMiddleware):
    async def dispatch(self, request: Request, call_next):
        if request.url.path.startswith("/v1/"):
            raw=await request.body()
            auth(request.headers.get("x-agent-time"),request.headers.get("x-agent-signature"),raw)
            async def receive(): return {"type":"http.request","body":raw,"more_body":False}
            request._receive=receive
        return await call_next(request)
app.add_middleware(HMACMiddleware)
