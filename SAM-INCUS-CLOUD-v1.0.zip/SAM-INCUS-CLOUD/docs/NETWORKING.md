# NAT networking and terminal access

Incus bridge NAT provides outbound internet access to containers. It does not provide a unique public IPv4 address or inbound SSH reachability for each instance.

## Recommended options
1. **Overlay VPN:** install a supported mesh VPN in each instance and give customers controlled access. This is usually the cleanest NAT-friendly approach.
2. **Bastion + port allocation:** allocate a unique host TCP port and proxy it to each instance's port 22. Maintain a database mapping and firewall rules; never let users choose arbitrary host ports.
3. **IPv6:** allocate globally routed IPv6 addresses if the host provider routes a prefix to the server; apply per-instance firewall rules.
4. **SSHX:** run the SSHX client inside the instance and deliver its generated sharing URL privately. Verify the current upstream install method and terms before enabling it.
5. **Tmate:** use a self-hosted tmate server for production. Do not assume the retired public `ssh.tmate.io` service is available.

## Why v1 does not auto-start terminal tools
SSHX/tmate links are bearer credentials: anyone holding the link may gain terminal access. A production implementation must create sessions only after owner authorization, deliver links ephemerally, set expiry/revocation, avoid logging secrets, and ensure outbound connectivity from the container. The bot's `/terminal` command is deliberately a placeholder until those controls and the preferred SSH route are configured.
