CREATE TABLE IF NOT EXISTS referrals (
  guild_id BIGINT NOT NULL, inviter_id BIGINT NOT NULL, invitee_id BIGINT NOT NULL,
  active BOOLEAN NOT NULL DEFAULT TRUE, joined_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  left_at TIMESTAMPTZ, PRIMARY KEY(guild_id, invitee_id)
);
CREATE INDEX IF NOT EXISTS referrals_inviter_active ON referrals(guild_id, inviter_id) WHERE active;
CREATE TABLE IF NOT EXISTS vps (
  id BIGSERIAL PRIMARY KEY, guild_id BIGINT NOT NULL, owner_id BIGINT NOT NULL,
  instance_name TEXT NOT NULL UNIQUE, plan_key TEXT NOT NULL, os_key TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'provisioning', created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  deleted_at TIMESTAMPTZ
);
CREATE INDEX IF NOT EXISTS vps_owner_active ON vps(guild_id, owner_id) WHERE deleted_at IS NULL;
CREATE TABLE IF NOT EXISTS audit_log (
  id BIGSERIAL PRIMARY KEY, actor_id BIGINT, action TEXT NOT NULL,
  target TEXT, details JSONB NOT NULL DEFAULT '{}'::jsonb, created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
