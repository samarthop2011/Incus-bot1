import hashlib, hmac, json, os, time
import aiohttp

class AgentClient:
    def __init__(self):
        self.url=os.environ["AGENT_URL"].rstrip("/")
        self.secret=os.environ["AGENT_SHARED_SECRET"].encode()
    async def request(self, method, path, payload=None):
        body=(b"" if method=="GET" else json.dumps(payload or {},separators=(",",":")).encode())
        stamp=str(int(time.time()))
        sig=hmac.new(self.secret,stamp.encode()+b"."+body,hashlib.sha256).hexdigest()
        headers={"X-Agent-Time":stamp,"X-Agent-Signature":sig,"Content-Type":"application/json"}
        timeout=aiohttp.ClientTimeout(total=260)
        async with aiohttp.ClientSession(timeout=timeout) as s:
            async with s.request(method,self.url+path,data=body if method!="GET" else None,headers=headers) as r:
                data=await r.json(content_type=None)
                if r.status>=400: raise RuntimeError(data.get("detail",f"Agent HTTP {r.status}"))
                return data
