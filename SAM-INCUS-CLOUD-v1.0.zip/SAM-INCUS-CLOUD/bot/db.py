import asyncpg, os
pool=None
async def init():
    global pool
    pool=await asyncpg.create_pool(os.environ["DATABASE_URL"],min_size=1,max_size=10)
    async with pool.acquire() as c:
        await c.execute(open("/app/database.sql").read())
async def close():
    if pool: await pool.close()
async def referrals(guild_id,user_id):
    async with pool.acquire() as c:
        return await c.fetchval("SELECT count(*) FROM referrals WHERE guild_id=$1 AND inviter_id=$2 AND active",guild_id,user_id) or 0
async def add_referral(guild_id,inviter,invitee):
    if not inviter or inviter==invitee: return
    async with pool.acquire() as c:
        await c.execute("INSERT INTO referrals(guild_id,inviter_id,invitee_id) VALUES($1,$2,$3) ON CONFLICT(guild_id,invitee_id) DO NOTHING",guild_id,inviter,invitee)
async def remove_referral(guild_id,invitee):
    async with pool.acquire() as c:
        await c.execute("UPDATE referrals SET active=FALSE,left_at=NOW() WHERE guild_id=$1 AND invitee_id=$2",guild_id,invitee)
async def create_vps(guild_id,owner,name,plan,os_key):
    async with pool.acquire() as c:
        return await c.fetchrow("INSERT INTO vps(guild_id,owner_id,instance_name,plan_key,os_key) VALUES($1,$2,$3,$4,$5) RETURNING id",guild_id,owner,name,plan,os_key)
async def set_vps_status(name,status):
    async with pool.acquire() as c: await c.execute("UPDATE vps SET status=$2 WHERE instance_name=$1",name,status)
async def active_vps(guild_id,owner):
    async with pool.acquire() as c: return await c.fetch("SELECT * FROM vps WHERE guild_id=$1 AND owner_id=$2 AND deleted_at IS NULL ORDER BY created_at DESC",guild_id,owner)
async def get_vps(guild_id,owner,name):
    async with pool.acquire() as c: return await c.fetchrow("SELECT * FROM vps WHERE guild_id=$1 AND owner_id=$2 AND instance_name=$3 AND deleted_at IS NULL",guild_id,owner,name)
async def delete_vps_record(name):
    async with pool.acquire() as c: await c.execute("UPDATE vps SET deleted_at=NOW(),status='deleted' WHERE instance_name=$1",name)
async def audit(actor,action,target=None,details=None):
    async with pool.acquire() as c: await c.execute("INSERT INTO audit_log(actor_id,action,target,details) VALUES($1,$2,$3,$4::jsonb)",actor,action,target,__import__('json').dumps(details or {}))
