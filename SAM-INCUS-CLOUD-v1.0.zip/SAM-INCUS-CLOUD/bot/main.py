import asyncio, os, secrets, string, logging
import discord
from discord import app_commands
from discord.ext import commands
from redis.asyncio import Redis
from . import db
from .agent_client import AgentClient
from config.plans import PLANS, OS_IMAGES

logging.basicConfig(level=logging.INFO,format="%(asctime)s %(levelname)s %(name)s: %(message)s")
log=logging.getLogger("sam-incus-cloud")
intents=discord.Intents.default(); intents.members=True
bot=commands.Bot(command_prefix="!",intents=intents)
agent=AgentClient(); redis=None; invite_cache={}

def is_admin(member):
    ids={int(x.strip()) for x in os.getenv("ADMIN_ROLE_IDS","").split(",") if x.strip().isdigit()}
    return member.guild_permissions.administrator or any(r.id in ids for r in member.roles)

def embed(title,description="",color=0x5865F2):
    e=discord.Embed(title=title,description=description,color=color)
    e.set_footer(text="SAM INCUS CLOUD • Infrastructure made simple")
    return e

class OSSelect(discord.ui.Select):
    def __init__(self,plan_key):
        self.plan_key=plan_key
        super().__init__(placeholder="Choose an operating system",options=[discord.SelectOption(label=v[0],value=k) for k,v in OS_IMAGES.items()])
    async def callback(self,interaction):
        await interaction.response.defer(ephemeral=True,thinking=True)
        plan=PLANS[self.plan_key]
        if plan.ram_gb is None:
            await interaction.followup.send("Enterprise Ultimate requires staff approval. Please open a support ticket.",ephemeral=True); return
        count=await db.referrals(interaction.guild_id,interaction.user.id)
        if count<plan.invites:
            await interaction.followup.send(f"You need **{plan.invites-count}** more active successful invite(s) for this plan.",ephemeral=True); return
        max_vps=int(os.getenv("MAX_VPS_PER_USER","3"))
        existing=await db.active_vps(interaction.guild_id,interaction.user.id)
        if len(existing)>=max_vps:
            await interaction.followup.send(f"You have reached the VPS limit ({max_vps}).",ephemeral=True); return
        lock=await redis.set(f"deploy:{interaction.guild_id}:{interaction.user.id}","1",nx=True,ex=900)
        if not lock:
            await interaction.followup.send("A deployment is already running for your account.",ephemeral=True); return
        name=f"sam-{interaction.user.id}-{''.join(secrets.choice(string.ascii_lowercase+string.digits) for _ in range(6))}"
        os_name,image=OS_IMAGES[self.values[0]]
        await interaction.followup.send(embed=embed("Deployment started",f"Instance: `{name}`\nPlan: **{plan.name}**\nOS: **{os_name}**\n\nProvisioning your VPS. This can take a few minutes."),ephemeral=True)
        try:
            await db.create_vps(interaction.guild_id,interaction.user.id,name,self.plan_key,self.values[0])
            await agent.request("POST","/v1/create",{"name":name,"image":image,"ram_gb":plan.ram_gb,"vcores":plan.vcores,"disk_gb":plan.disk_gb})
            await db.set_vps_status(name,"running")
            await db.audit(interaction.user.id,"vps.create",name,{"plan":plan.key,"os":self.values[0]})
            await interaction.followup.send(embed=embed("VPS deployed successfully",f"**Instance:** `{name}`\n**Plan:** {plan.name}\n**Resources:** {plan.ram_gb} GB RAM • {plan.vcores} vCPU • {plan.disk_gb} GB SSD\n**OS:** {os_name}\n**Network:** NAT (outbound internet)\n\nUse `/myvps` to manage it. Use `/terminal` to create an SSHX or tmate session.",0x2ECC71),ephemeral=True)
        except Exception as ex:
            await db.set_vps_status(name,"failed")
            log.exception("Deployment failed")
            await interaction.followup.send(embed=embed("Deployment failed",f"`{str(ex)[:700]}`\nPlease contact staff if this continues.",0xE74C3C),ephemeral=True)
        finally: await redis.delete(f"deploy:{interaction.guild_id}:{interaction.user.id}")

class DeployView(discord.ui.View):
    def __init__(self):
        super().__init__(timeout=300)
        self.add_item(PlanSelect())
class PlanSelect(discord.ui.Select):
    def __init__(self):
        opts=[discord.SelectOption(label=f"{p.name} • {p.invites} invites",value=p.key,description=(f"{p.ram_gb} GB RAM / {p.vcores} vCPU / {p.disk_gb} GB SSD" if p.ram_gb else "Custom resources • staff approval")) for p in PLANS.values()]
        super().__init__(placeholder="Select your VPS plan",options=opts)
    async def callback(self,interaction):
        p=PLANS[self.values[0]]; count=await db.referrals(interaction.guild_id,interaction.user.id)
        if count<p.invites:
            await interaction.response.send_message(f"{p.name} requires **{p.invites} active invites**. You currently have **{count}**.",ephemeral=True); return
        if p.ram_gb is None:
            await interaction.response.send_message("Enterprise Ultimate is custom and requires staff approval. Contact an administrator.",ephemeral=True); return
        view=discord.ui.View(timeout=180); view.add_item(OSSelect(p.key))
        await interaction.response.send_message(embed=embed(f"{p.name} plan",f"**Required invites:** {p.invites}\n**Resources:** {p.ram_gb} GB RAM • {p.vcores} vCPU • {p.disk_gb} GB SSD\n\nChoose your operating system."),view=view,ephemeral=True)

@bot.event
async def on_ready():
    log.info("Logged in as %s",bot.user)
    for g in bot.guilds:
        try: invite_cache[g.id]={i.code:i.uses for i in await g.invites()}
        except discord.Forbidden: log.warning("Invite tracking needs Manage Server permission in %s",g.id)
    try:
        guild_id=int(os.getenv("GUILD_ID","0"))
        if guild_id: await bot.tree.sync(guild=discord.Object(id=guild_id))
        else: await bot.tree.sync()
    except Exception: log.exception("Slash command sync failed")

@bot.event
async def on_member_join(member):
    try:
        current=await member.guild.invites(); old=invite_cache.get(member.guild.id,{})
        used=next((i for i in current if i.uses>(old.get(i.code,0))),None)
        invite_cache[member.guild.id]={i.code:i.uses for i in current}
        if used and used.inviter and (discord.utils.utcnow()-member.created_at).days>=int(os.getenv("MIN_ACCOUNT_AGE_DAYS","7")):
            await db.add_referral(member.guild.id,used.inviter.id,member.id)
    except discord.Forbidden: log.warning("Cannot inspect invites for guild %s",member.guild.id)
    except Exception: log.exception("Invite tracking error")

@bot.event
async def on_member_remove(member):
    await db.remove_referral(member.guild.id,member.id)

@bot.tree.command(name="panel",description="Open the SAM INCUS CLOUD control centre")
async def panel(interaction):
    e=embed("☁ SAM INCUS CLOUD","Welcome to your cloud control centre.\n\nSelect a plan to deploy a VPS, inspect your existing instances or check your invite balance.")
    e.add_field(name="Self-service deployment",value="Choose a plan • Select an OS • Deploy automatically",inline=False)
    await interaction.response.send_message(embed=e,view=DeployView())

@bot.tree.command(name="plans",description="View all invite-based VPS plans")
async def plans(interaction):
    e=embed("Available VPS plans")
    for p in PLANS.values():
        spec=f"{p.ram_gb} GB RAM • {p.vcores} vCPU • {p.disk_gb} GB SSD" if p.ram_gb else "Custom resources • staff approval"
        e.add_field(name=f"{p.name} — {p.invites} invites",value=spec,inline=False)
    await interaction.response.send_message(embed=e,ephemeral=True)

@bot.tree.command(name="invites",description="Check your active successful invites")
async def invites(interaction):
    n=await db.referrals(interaction.guild_id,interaction.user.id)
    eligible=", ".join(p.name for p in PLANS.values() if n>=p.invites) or "None yet"
    await interaction.response.send_message(embed=embed("Your invite balance",f"**Active successful invites:** {n}\n**Eligible plans:** {eligible}\n\nOnly attributed members who remain in the server count. New accounts younger than the configured minimum are excluded."),ephemeral=True)

@bot.tree.command(name="myvps",description="List and manage your VPS instances")
async def myvps(interaction):
    rows=await db.active_vps(interaction.guild_id,interaction.user.id)
    if not rows: await interaction.response.send_message("You do not have any VPS instances yet. Use `/panel` to deploy one.",ephemeral=True); return
    e=embed("Your VPS instances")
    for r in rows: e.add_field(name=r['instance_name'],value=f"Plan: {r['plan_key']} • OS: {r['os_key']} • Status: {r['status']}",inline=False)
    await interaction.response.send_message(embed=e,view=ManageView(rows),ephemeral=True)

class ManageSelect(discord.ui.Select):
    def __init__(self,rows):
        self.names=[r['instance_name'] for r in rows]
        super().__init__(placeholder="Choose a VPS",options=[discord.SelectOption(label=n,value=n) for n in self.names[:25]])
    async def callback(self,interaction):
        name=self.values[0]; view=ActionView(name)
        await interaction.response.send_message(embed=embed("VPS management",f"Selected instance: `{name}`\nChoose an action."),view=view,ephemeral=True)
class ManageView(discord.ui.View):
    def __init__(self,rows): super().__init__(timeout=180); self.add_item(ManageSelect(rows))
class ActionView(discord.ui.View):
    def __init__(self,name):
        super().__init__(timeout=180); self.name=name
        for label,action in [("Start","start"),("Stop","stop"),("Restart","restart")]:
            b=discord.ui.Button(label=label,style=discord.ButtonStyle.primary)
            b.callback=self.make_callback(action); self.add_item(b)
    def make_callback(self,action):
        async def cb(interaction):
            if not await db.get_vps(interaction.guild_id,interaction.user.id,self.name):
                await interaction.response.send_message("That VPS does not belong to you.",ephemeral=True); return
            await interaction.response.defer(ephemeral=True,thinking=True)
            try:
                result=await agent.request("POST","/v1/action",{"name":self.name,"action":action})
                await db.audit(interaction.user.id,"vps."+action,self.name)
                await interaction.followup.send(f"`{self.name}`: {action} command completed.",ephemeral=True)
            except Exception as ex: await interaction.followup.send(f"Operation failed: `{str(ex)[:500]}`",ephemeral=True)
        return cb

@bot.tree.command(name="terminal",description="Create a temporary SSHX or tmate terminal session")
@app_commands.describe(instance="Your VPS name",method="Terminal sharing provider")
@app_commands.choices(method=[app_commands.Choice(name="SSHX",value="sshx"),app_commands.Choice(name="Tmate (self-hosted required)",value="tmate")])
async def terminal(interaction,instance:str,method:app_commands.Choice[str]):
    if not await db.get_vps(interaction.guild_id,interaction.user.id,instance):
        await interaction.response.send_message("VPS not found or not owned by you.",ephemeral=True); return
    await interaction.response.send_message("Terminal session provisioning is not enabled in this initial secure build. Use the included SSH key / NAT networking guide; SSHX/tmate adapters are provided as a follow-on integration point.",ephemeral=True)

@bot.tree.command(name="admin-node",description="Check Incus node connectivity (admin)")
async def admin_node(interaction):
    if not is_admin(interaction.user): await interaction.response.send_message("Administrator only.",ephemeral=True); return
    await interaction.response.defer(ephemeral=True)
    try: r=await agent.request("GET","/health"); await interaction.followup.send(f"Agent online. Incus: `{r.get('incus','available')}`",ephemeral=True)
    except Exception as ex: await interaction.followup.send(f"Node check failed: `{str(ex)[:500]}`",ephemeral=True)

async def main():
    global redis
    await db.init(); redis=Redis.from_url(os.environ["REDIS_URL"],decode_responses=True)
    await bot.start(os.environ["DISCORD_TOKEN"])

if __name__=="__main__": asyncio.run(main())
