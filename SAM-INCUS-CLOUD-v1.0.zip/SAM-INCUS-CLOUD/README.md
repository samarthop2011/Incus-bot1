# SAM INCUS CLOUD v1.0

A Discord self-service Incus VPS provisioning starter platform. Includes invite-based plans, OS selection, PostgreSQL records, Redis deployment locks, a Dockerized Discord bot, and a restricted host-side provisioning agent.

> **Important:** NAT bridge networking gives instances outbound connectivity. It does not automatically give every VPS a public inbound SSH endpoint. For inbound SSH, configure a VPN/overlay, a bastion, IPv6, or carefully managed port forwarding. SSHX/tmate terminal-sharing adapters are not enabled in this initial secure release; see `docs/NETWORKING.md`.

## Included features
- Invite-count plan eligibility (active attributed members only)
- Dirt through Enterprise Ultimate plans matching the supplied specs
- OS dropdown: Debian 12/13, Ubuntu 22.04/24.04, Alpine 3.19
- Incus instance provisioning with CPU, memory and disk limits
- `/panel`, `/plans`, `/invites`, `/myvps`, `/terminal`, `/admin-node`
- Start / stop / restart controls, audit log, user ownership checks
- Docker Compose, PostgreSQL, Redis, host provisioning agent
- HMAC-authenticated agent API and strict instance/image allowlists

## Requirements
- Debian 12/13 or Ubuntu 22.04/24.04 host with Incus installed and initialized
- Docker Engine + Docker Compose plugin
- Discord application/bot with Server Members Intent enabled
- Bot permissions: View Channels, Send Messages, Embed Links, Use Application Commands, Manage Server (for invite attribution)
- Incus default profile configured with a NAT bridge NIC and root disk pool

## 1. Prepare Incus on the host
Install Incus using the official documentation for your distribution, then run:

```bash
sudo incus admin init
incus version
incus network list
incus profile show default
```

The default profile must have an `eth0` device attached to your NAT bridge (commonly `incusbr0`) and a `root` disk device using your storage pool. Confirm the bridge has NAT enabled. Do not expose the Incus API to the public internet.

## 2. Install the host agent
Run these commands from the project directory on the Incus host:

```bash
sudo apt update && sudo apt install -y python3-venv python3-pip
sudo install -d -m 0750 /opt/sam-incus-agent
sudo cp agent/agent.py /opt/sam-incus-agent/agent.py
sudo python3 -m venv /opt/sam-incus-agent/venv
sudo /opt/sam-incus-agent/venv/bin/pip install -r agent/requirements.txt
```

Create a long secret and save it for both the agent and bot:

```bash
openssl rand -hex 32
sudo install -m 0600 /dev/null /etc/sam-incus-agent.env
sudo nano /etc/sam-incus-agent.env
```

Put `AGENT_SHARED_SECRET=THE_SAME_64_CHARACTER_SECRET` in that file. Install the service:

```bash
sudo cp agent/sam-incus-agent.service /etc/systemd/system/
sudo sed -i 's#ExecStart=/usr/bin/python3 -m uvicorn#ExecStart=/opt/sam-incus-agent/venv/bin/uvicorn#' /etc/systemd/system/sam-incus-agent.service
sudo systemctl daemon-reload
sudo systemctl enable --now sam-incus-agent
sudo systemctl status sam-incus-agent --no-pager
```

The agent listens on port 8787. The Docker client signs POST requests with HMAC; health is intentionally a minimal unauthenticated liveness endpoint. Restrict access to the Docker bridge subnet with your host firewall. Example (adjust the subnet to your actual Docker network):

```bash
sudo ufw allow from 172.18.0.0/16 to any port 8787 proto tcp
sudo ufw deny 8787/tcp
```

Check your firewall ordering and Docker's iptables behavior; Docker-published ports can bypass UFW. This service is not published by Compose. Do not forward 8787 on your router or expose it publicly.

## 3. Configure Discord
1. Create an application in the Discord Developer Portal and add a bot.
2. Enable **Server Members Intent**. Invite tracking also requires the bot to have **Manage Server** so it can inspect invite usage.
3. Invite the bot with `bot` and `applications.commands` scopes. Grant View Channels, Send Messages, Embed Links, Use Application Commands, and Manage Server.
4. Copy `.env.example` to `.env` and fill in the token, guild ID, admin role IDs and agent secret.

## 4. Start

```bash
cp .env.example .env
nano .env
```

Add `POSTGRES_PASSWORD` to `.env` (use a strong random password):

```bash
printf '\nPOSTGRES_PASSWORD=%s\n' "$(openssl rand -hex 24)" >> .env
```

Ensure `AGENT_SHARED_SECRET` matches `/etc/sam-incus-agent.env`, then:

```bash
docker compose build
docker compose up -d
docker compose logs -f bot
```

Use `/admin-node` to test connectivity and `/panel` to publish the customer control panel.

## 5. Invite tracking caveats
- Invite attribution is based on the increase in invite `uses` between cache refreshes. If multiple people join at the exact same time, Discord's invite data may not uniquely identify the inviter. Treat attribution as best-effort, not billing-grade proof.
- The bot must have Manage Server to read invite usage.
- Accounts younger than `MIN_ACCOUNT_AGE_DAYS` are ignored.
- A referral stops counting when the invitee leaves.
- Vanity URL joins and joins where Discord does not expose a changed invite are not credited.
- For a large public hosting business, add manual dispute review and anti-alt verification before granting expensive plans.

## 6. Security checklist before public launch
- Change all secrets and protect `.env` (chmod 600).
- Restrict port 8787 to the Docker bridge subnet.
- Keep the host agent off the public internet; HMAC is authentication, not encryption.
- Use a private host network or TLS/mTLS if traffic crosses an untrusted network.
- Configure Incus project/resource quotas and a dedicated storage pool.
- Set sensible max VPS per user, account age and invite rules.
- Add staff approval for Enterprise plans and enforce total node capacity.
- Back up PostgreSQL and Incus storage regularly.
- Review the source code and test on a non-production node before accepting customers.

## Current limitations (honest v1 scope)
- `/terminal` currently returns a secure setup notice; SSHX and tmate automation are not active yet. NAT-only networking does not create inbound SSH reachability.
- No web dashboard, billing, snapshots, backup scheduler, automated node scheduler, custom Enterprise provisioning or OS reinstall yet.
- The agent has create/start/stop/restart/delete operations; instance deletion is not exposed to ordinary users in the bot.
- No capacity scheduler yet; a single Incus host is assumed.
- The invite tracker is best-effort and should not be used as the sole proof for high-value rewards.

## Troubleshooting
```bash
sudo journalctl -u sam-incus-agent -n 100 --no-pager
docker compose logs --tail=150 bot
docker compose ps
incus list
incus profile show default
```
If deployment fails with a root-device error, check the default profile root disk device and storage pool. If instances have no internet, check that the NAT bridge is configured and forwarding is enabled. If `/admin-node` cannot connect, check the Docker bridge subnet and firewall rules.
