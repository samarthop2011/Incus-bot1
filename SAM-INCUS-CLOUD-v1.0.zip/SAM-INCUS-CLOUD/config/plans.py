from dataclasses import dataclass

@dataclass(frozen=True)
class Plan:
    key: str
    name: str
    invites: int
    ram_gb: int | None
    vcores: int | None
    disk_gb: int | None
    description: str

PLANS = {
    p.key: p for p in [
        Plan("dirt", "Dirt", 2, 4, 1, 25, "Entry cloud instance"),
        Plan("stone", "Stone", 4, 6, 2, 40, "Starter workload"),
        Plan("iron", "Iron", 6, 8, 2, 60, "Balanced compute"),
        Plan("gold", "Gold", 8, 12, 4, 80, "Power user"),
        Plan("diamond", "Diamond", 12, 16, 4, 100, "High performance"),
        Plan("netherite", "Netherite", 15, 20, 6, 100, "Heavy workloads"),
        Plan("high_demand", "High Demand", 20, 32, 6, 125, "Large workloads"),
        Plan("enterprise", "Enterprise Specs", 26, 48, 8, 150, "Staff-reviewed enterprise tier"),
        Plan("enterprise_ultimate", "Enterprise Ultimate", 29, None, None, None, "Custom resources; staff approval required"),
    ]
}
OS_IMAGES = {
    "debian13": ("Debian 13", "images:debian/13"),
    "debian12": ("Debian 12", "images:debian/12"),
    "ubuntu2404": ("Ubuntu 24.04 LTS", "images:ubuntu/24.04"),
    "ubuntu2204": ("Ubuntu 22.04 LTS", "images:ubuntu/22.04"),
    "alpine319": ("Alpine Linux 3.19", "images:alpine/3.19"),
}
